
function switchToManual() {
  document.getElementById("manualInput").classList.remove("hidden");
}

function simulateManualCheck() {
  const plate = document.getElementById("plateInput").value.trim();
  if (plate === "") {
    alert("請輸入車牌號碼！");
    return;
  }

  // 模擬辨識結果（未串接後端）
  const isStolen = plate === "ABC-1234";
  const result = isStolen
    ? `🚨 贓車！車號 ${plate}，登記車色：黑色`
    : `✅ 正常車輛，車號 ${plate}，登記車色：銀色`;

  document.getElementById("resultText").textContent = result;
}
