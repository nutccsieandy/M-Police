
document.getElementById("reportForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const plate = document.getElementById("plateNumber").value.trim();
  const desc = document.getElementById("description").value.trim();

  if (desc === "") {
    alert("請填寫可疑狀況說明");
    return;
  }

  // 模擬回傳結果
  document.getElementById("resultText").textContent =
    "✅ 通報成功，感謝您的協助，我們已轉交資料給後台單位進行處理。";
});
