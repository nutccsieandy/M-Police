
function switchTab(tabId) {
  const contents = document.querySelectorAll(".tab-content");
  contents.forEach(tab => tab.classList.add("hidden"));
  document.getElementById(tabId).classList.remove("hidden");
}
